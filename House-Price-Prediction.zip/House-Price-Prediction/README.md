# 🏠 House Price Prediction

A machine learning web app that estimates house prices from property and location details.
It trains and compares **Linear Regression**, **Decision Tree** and **Random Forest** models
and serves predictions through an interactive **Streamlit** interface.

## Features
- **Instant price prediction** with a likely price range
- **Multi-model comparison** (R², MAE, RMSE) on unseen test data
- **Feature importance** chart showing what drives house prices
- **Data explorer** with a map and dataset insights

## Results (20% hold-out test set, 4,128 houses)

| Model | R² | MAE | RMSE |
|---|---|---|---|
| Linear Regression | 0.597 | $50,889 | $72,669 |
| Decision Tree | 0.731 | $39,034 | $59,414 |
| **Random Forest** | **0.809** | **$32,212** | **$49,997** |

## Dataset
[California Housing](https://github.com/ageron/handson-ml2/tree/master/datasets/housing)
(20,640 census block groups, 1990). Prices are for demonstration only.

## Tech stack
Python · Scikit-learn · Pandas · NumPy · Streamlit

## Run locally
```bash
pip install -r requirements.txt
python train.py          # trains the models (optional, models are already included)
streamlit run app.py
```

## Project structure
```
app.py            Streamlit web app
train.py          Feature engineering, model training and evaluation
data/housing.csv  Dataset
models.joblib     Trained models
metrics.json      Evaluation results
```
